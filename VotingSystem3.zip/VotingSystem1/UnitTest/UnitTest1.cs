﻿using System;
using System.Linq;
using Windows.UI.Xaml.Controls;


namespace UnitTest
{
    class UnitTest1
    {
        private float X;// set a coordinate X

        private float Y;// set a coordinate Y

        public float Width { get; private set; }
        public float Height { get; private set; }

        void Form1_Resize(object sender, EventArgs e)
        {
            float newx = (this.Width) / X;
            float newy = this.Height / Y;
          

        }
        public float result(float newx, float newy)
        {
            return (newx+newy);
        }
            static void Main(string[] args)
        {

        }
    }

}
