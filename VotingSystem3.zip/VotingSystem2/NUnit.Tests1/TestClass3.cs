﻿// NUnit 3 tests
// See documentation : https://github.com/nunit/docs/wiki/NUnit-Documentation
using System;
using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;

namespace NUnit.Tests1
{
    [TestFixture]
    public class TestClass3
    {

        ArrayList Font_Box = new ArrayList {1,2,3,4 };

        private Font TopicId_lab;
        private Font Topic_lab;
        private Font Dealine_lab;
        private Font Limited_lab;
        private Font Candidate1;
        private Font Candidate1_lab;
        private Font Candidate2;
        private Font Candidate2_lab;
        private Font Candidate3;
        private Font Candidate3_lab;
        private Font Candidate4;
        private Font Candidate4_lab;
        private Font OK_btn;
        private Font Home_btn;
        private Font Exit_btn;
        private Font Font_lab;

        [Test]
        public void TestMethod()
        {
            if (Font_Box[0].ToString() == "1")
            {
                object FontStyle = 10;
                object Font_lab = 1;
                Font_lab = new Font("Tahoma", 10, FontStyle);
                TopicId_lab = new Font("Tahoma", 10, FontStyle);
                Topic_lab = new Font("Tahoma", 10, FontStyle);
                Dealine_lab = new Font("Tahoma", 10, FontStyle);
                Limited_lab = new Font("Tahoma", 10, FontStyle);
                Candidate1 = new Font("Tahoma", 10, FontStyle);
                Candidate1_lab = new Font("Tahoma", 10, FontStyle);
                Candidate2 = new Font("Tahoma", 10, FontStyle);
                Candidate2_lab = new Font("Tahoma", 10, FontStyle);
                Candidate3 = new Font("Tahoma", 10, FontStyle);
                Candidate3_lab = new Font("Tahoma", 10, FontStyle);
                Candidate4= new Font("Tahoma", 10, FontStyle);
                Candidate4_lab = new Font("Tahoma", 10, FontStyle);
                OK_btn = new Font("Tahoma", 10, FontStyle);
                Home_btn = new Font("Tahoma", 10, FontStyle);
                
                Exit_btn = new Font("Tahoma", 10, FontStyle);
            }
            if (Font_Box[0].ToString() == "2")
            {
                object FontStyle = 10;
                Font_lab = new Font("Tahoma", 12, FontStyle);
                TopicId_lab = new Font("Tahoma", 12, FontStyle);
                Topic_lab = new Font("Tahoma", 12, FontStyle);
                Dealine_lab = new Font("Tahoma", 12, FontStyle);
                Limited_lab = new Font("Tahoma", 12, FontStyle);
                Candidate1= new Font("Tahoma", 12, FontStyle);
                Candidate1_lab = new Font("Tahoma", 12, FontStyle);
                Candidate2 = new Font("Tahoma", 12, FontStyle);
                Candidate2_lab = new Font("Tahoma", 12, FontStyle);
                Candidate3 = new Font("Tahoma", 12, FontStyle);
                Candidate3_lab = new Font("Tahoma", 12, FontStyle);
                Candidate4 = new Font("Tahoma", 12, FontStyle);
                Candidate4_lab = new Font("Tahoma", 12, FontStyle);
                OK_btn = new Font("Tahoma", 12, FontStyle);
                Home_btn = new Font("Tahoma", 12, FontStyle);
                Exit_btn = new Font("Tahoma", 12, FontStyle);
            }
            if (Font_Box[0].ToString() == "3")
            {
                object FontStyle = 20;
                Font_lab = new Font("Tahoma", 14, FontStyle);
                TopicId_lab = new Font("Tahoma", 14, FontStyle);
                Topic_lab = new Font("Tahoma", 14, FontStyle);
                Dealine_lab = new Font("Tahoma", 14, FontStyle);
                Limited_lab = new Font("Tahoma", 14, FontStyle);
                Candidate1 = new Font("Tahoma", 14, FontStyle);
                Candidate1_lab = new Font("Tahoma", 14, FontStyle);
                Candidate2 = new Font("Tahoma", 14, FontStyle);
                Candidate2_lab = new Font("Tahoma", 14, FontStyle);
                Candidate3 = new Font("Tahoma", 14, FontStyle);
                Candidate3_lab = new Font("Tahoma", 14, FontStyle);
                Candidate4 = new Font("Tahoma", 14, FontStyle);
                Candidate4_lab = new Font("Tahoma", 14, FontStyle);
                OK_btn = new Font("Tahoma", 14, FontStyle);
                Home_btn = new Font("Tahoma", 14, FontStyle);
                Exit_btn = new Font("Tahoma", 14, FontStyle);
            }
            if (Font_Box[0].ToString() == "4")
            {
                object FontStyle = 25;
                Font_lab = new Font("Tahoma", 15, FontStyle);
                TopicId_lab = new Font("Tahoma", 15, FontStyle);
                Topic_lab = new Font("Tahoma", 15, FontStyle);
                Dealine_lab = new Font("Tahoma", 15, FontStyle);
                Limited_lab = new Font("Tahoma", 15, FontStyle);
                Candidate1 = new Font("Tahoma", 15, FontStyle);
                Candidate1_lab = new Font("Tahoma", 15, FontStyle);
                Candidate2 = new Font("Tahoma", 15, FontStyle);
                Candidate2_lab = new Font("Tahoma", 15, FontStyle);
                Candidate3 = new Font("Tahoma", 15, FontStyle);
                Candidate3_lab = new Font("Tahoma", 15, FontStyle);
                Candidate4 = new Font("Tahoma", 15, FontStyle);
                Candidate4_lab = new Font("Tahoma", 15, FontStyle);
                OK_btn = new Font("Tahoma", 15, FontStyle);
                Home_btn = new Font("Tahoma", 15, FontStyle);
                Exit_btn = new Font("Tahoma", 15, FontStyle);
            }
            return;
        }
        }
      
        }
    


namespace NUnit.Tests1
{
    class Font
    {
        private string v1;
        private int v2;
        private object bold;

        public Font(string v1, int v2, object bold)
        {
            this.v1 = v1;
            this.v2 = v2;
            this.bold = bold;
        }

        public static implicit operator Font(int v)
        {
            throw new NotImplementedException();
        }
    }
}