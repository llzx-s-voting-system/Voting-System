﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Windows.Forms.DataVisualization.Charting;

namespace VotingSystem
{
    public partial class DataForm : Form
    {
        public DataForm()
        {
            InitializeComponent();
        }
        string strcon, strsql;
        SqlConnection mycon;
        SqlCommand command;
        DataSet ds;
        SqlDataAdapter da;
        //connect to the database
        string Key;//Key word

        private bool DBConnect()
        {


            try
            {
                strcon = "Data Source=localhost;Initial Catalog=VOTING;Integrated Security=True";
                mycon = new SqlConnection(strcon);
                mycon.Open();

                MessageBox.Show("Connect to database successfully");
                return true;
            }
            catch
            {
                MessageBox.Show("Connect to database unsuccessfully");
                return false;
            }
            //Check the database
        }

        private void showDataGrid()
        {
            strsql = "select * from Topic";
            command = new SqlCommand(strsql, mycon);
            command.ExecuteScalar();
            ds = new DataSet();
            da = new SqlDataAdapter(command);
            da.Fill(ds, "topic");
            VotingData_GV.DataSource = ds.Tables["topic"];
            //Show information  from topic table
         }

        private void VotingData_GV_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Candidate1_lab.Text = VotingData_GV.CurrentRow.Cells[3].Value.ToString();
            Candidate2_lab.Text = VotingData_GV.CurrentRow.Cells[4].Value.ToString();
            Candidate3_lab.Text = VotingData_GV.CurrentRow.Cells[5].Value.ToString();
            Candidate4_lab.Text = VotingData_GV.CurrentRow.Cells[6].Value.ToString();
            Candidate1_txt.Text = VotingData_GV.CurrentRow.Cells[8].Value.ToString();
            Candidate2_txt.Text = VotingData_GV.CurrentRow.Cells[9].Value.ToString();
            Candidate3_txt.Text = VotingData_GV.CurrentRow.Cells[10].Value.ToString();
            Candidate4_txt.Text = VotingData_GV.CurrentRow.Cells[11].Value.ToString();
            // when user click data, the form will transfor date from table to textbox.
        }

        private void Show_btn_Click(object sender, EventArgs e)
        {
            chart1.Series.Clear();
            Series Strength = new Series("Number");
            Strength.ChartType = SeriesChartType.Column;
            Strength.Points.AddXY(Candidate1_lab.Text, Candidate1_txt.Text);
            Strength.Points.AddXY(Candidate2_lab.Text, Candidate2_txt.Text);
            Strength.Points.AddXY(Candidate3_lab.Text, Candidate3_txt.Text);
            Strength.Points.AddXY(Candidate4_lab.Text, Candidate4_txt.Text);
            chart1.Series.Add(Strength);
            // when user click this button, the form will shows the bar graph
        }

        private void VotingData_GV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Alter_btn_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Are you sure to update ID=" + Key, "inforamtion", MessageBoxButtons.OKCancel);
            //Show message "Are you sure to update"

            if (dr == DialogResult.OK)
            {
                DBConnect();
                strsql = string.Format("update Topic set Candidate1Voting='{0}',Candidate2Voting='{1}',Candidate3Voting='{2}',Candidate4Voting='{3}' where TopicId ='{4}'", Candidate1_txt.Text, Candidate2_txt.Text, Candidate3_txt.Text, Candidate4_txt.Text, Key);
                MessageBox.Show(strsql);
                command = new SqlCommand(strsql, mycon);
                try
                {

                    command.ExecuteScalar();
                    MessageBox.Show("Update successfully");
                    showDataGrid();
                }
                catch
                {
                    MessageBox.Show("uupdate failed");
                }
                //Check update
                finally
                {
                    mycon.Close();
                }
                //Close database
            }
        }

        



        private void Exit_btn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Font_Box_SelectedIndexChanged(object sender, EventArgs e)
        {  //Set a selection box to adjust font size
            if (Font_Box.Text[0].ToString() == "1")
            {
                Candidate1_lab.Font = new Font("Tahoma", 10, FontStyle.Bold);
                Candidate2_lab.Font = new Font("Tahoma", 10, FontStyle.Bold);
                Candidate3_lab.Font = new Font("Tahoma", 10, FontStyle.Bold);
                Candidate4_lab.Font = new Font("Tahoma", 10, FontStyle.Bold);
                Alter_btn.Font = new Font("Tahoma", 10, FontStyle.Bold);
                Show_btn.Font = new Font("Tahoma", 10, FontStyle.Bold);
                Exit_btn.Font = new Font("Tahoma", 10, FontStyle.Bold);
                Font_lab.Font = new Font("Tahoma", 10, FontStyle.Bold);
            }
            if (Font_Box.Text[0].ToString() == "2")
            {
                Candidate1_lab.Font = new Font("Tahoma", 12, FontStyle.Bold);
                Candidate2_lab.Font = new Font("Tahoma", 12, FontStyle.Bold);
                Candidate3_lab.Font = new Font("Tahoma", 12, FontStyle.Bold);
                Candidate4_lab.Font = new Font("Tahoma", 12, FontStyle.Bold);
                Alter_btn.Font = new Font("Tahoma", 12, FontStyle.Bold);
                Show_btn.Font = new Font("Tahoma", 12, FontStyle.Bold);
                Exit_btn.Font = new Font("Tahoma", 12, FontStyle.Bold);
                Font_lab.Font = new Font("Tahoma", 12, FontStyle.Bold);
            }
            if (Font_Box.Text[0].ToString() == "3")
            {
                Candidate1_lab.Font = new Font("Tahoma", 14, FontStyle.Bold);
                Candidate2_lab.Font = new Font("Tahoma", 14, FontStyle.Bold);
                Candidate3_lab.Font = new Font("Tahoma", 14, FontStyle.Bold);
                Candidate4_lab.Font = new Font("Tahoma", 14, FontStyle.Bold);
                Alter_btn.Font = new Font("Tahoma", 14, FontStyle.Bold);
                Show_btn.Font = new Font("Tahoma", 14, FontStyle.Bold);
                Exit_btn.Font = new Font("Tahoma", 14, FontStyle.Bold);
                Font_lab.Font = new Font("Tahoma", 14, FontStyle.Bold);
            }
            if (Font_Box.Text[0].ToString() == "4")
            {
                Candidate1_lab.Font = new Font("Tahoma", 15, FontStyle.Bold);
                Candidate2_lab.Font = new Font("Tahoma", 15, FontStyle.Bold);
                Candidate3_lab.Font = new Font("Tahoma", 15, FontStyle.Bold);
                Candidate4_lab.Font = new Font("Tahoma", 15, FontStyle.Bold);
                Alter_btn.Font = new Font("Tahoma", 15, FontStyle.Bold);
                Show_btn.Font = new Font("Tahoma", 15, FontStyle.Bold);
                Exit_btn.Font = new Font("Tahoma", 15, FontStyle.Bold);
                Font_lab.Font = new Font("Tahoma", 15, FontStyle.Bold);
            }
        }

        private void DataForm_Load(object sender, EventArgs e)
        {

            DBConnect();
            showDataGrid();
            VotingData_GV.RowHeadersVisible = false;
            this.VotingData_GV.Columns[0].Width = 80;
            this.VotingData_GV.Columns[1].Width = 80;
            this.VotingData_GV.Columns[2].Width = 80;
            this.VotingData_GV.Columns[3].Width = 80;
            this.VotingData_GV.Columns[4].Width = 80;
            this.VotingData_GV.Columns[5].Width = 80;
            this.VotingData_GV.Columns[6].Width = 80;
            this.VotingData_GV.Columns[7].Width = 80;
            this.VotingData_GV.Columns[8].Width = 80;
            this.VotingData_GV.Columns[9].Width = 80;
            this.VotingData_GV.Columns[10].Width = 80;
            this.VotingData_GV.Columns[11].Width = 80;
            VotingData_GV.ColumnHeadersDefaultCellStyle.Font = new Font("Tahoma", 7, FontStyle.Bold);
            // show database data in there and change font

            
        }
    }
}
