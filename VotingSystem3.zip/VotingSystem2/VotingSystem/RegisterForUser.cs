﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace VotingSystem
{
    public partial class RegisterForUser : Form
    {
        public RegisterForUser()
        {
            InitializeComponent();
            
        }

       

        string strcon, strsql;
        SqlConnection mycon;
        SqlCommand command;
        //connect to the database
        private bool DBConnect()
        {

           
            try
            {
                strcon = "Data Source=localhost;Initial Catalog=VOTING;Integrated Security=True";
                mycon = new SqlConnection(strcon);
                mycon.Open();
               
                MessageBox.Show("Connect to database successfully");
                return true;
            }
            catch
            {
                MessageBox.Show("Connect to database unsuccessfully");
                return false;
            }
            //Check the database
        }

       

        private void RegisterForUser_Load(object sender, EventArgs e)
        {
            
            
        }

        

        private void Exit_btn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Home_btn_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            this.Hide();
            login.ShowDialog(this);
        }

       

       



        private void OK_btn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(UserName_txt.Text))
            {
                MessageBox.Show("Please enter your username");
                return;
            }
            
            if (string.IsNullOrEmpty(Password_txt.Text))
            {
                MessageBox.Show("Please enter your password");
                return;
            }

            //if (string.IsNullOrEmpty(Role_comboBox.Text))
            //{
            //    MessageBox.Show("Choose your role please");
            //    return;
            //}

            if (DBConnect())
            {
                strsql = string.Format("insert into VotingUsers(UserId,UserName,Password,Telephone,Email,Role,Reason) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}')", UserId_txt.Text,UserName_txt.Text, Password_txt.Text, Tel_txt.Text, Email_txt.Text, Role_comboBox.Text,Reason_txt);
                //Add information in the database
                MessageBox.Show(strsql);
                command = new SqlCommand(strsql, mycon);
                try
                {
                    command.ExecuteScalar();
                    MessageBox.Show("Register successfully");

                }
                catch
                {
                    MessageBox.Show("Register failed");
                }
                //Check register
                finally
                {
                    mycon.Close();
                }
                //Close the database
            }
            }

        private void Font_Box_SelectedIndexChanged(object sender, EventArgs e)
        {    //Set a selection box to adjust font size
            if (Font_Box.Text[0].ToString() == "1")
            {
                UserId_lab.Font = new Font("Tahoma", 10, FontStyle.Bold);
                Password_lab.Font = new Font("Tahoma", 10, FontStyle.Bold);
                UserName_lab.Font = new Font("Tahoma", 10, FontStyle.Bold);
                Role_lab.Font = new Font("Tahoma", 10, FontStyle.Bold);
                OK_btn.Font = new Font("Tahoma", 10, FontStyle.Bold);
                Home_btn.Font = new Font("Tahoma", 10, FontStyle.Bold);
                Exit_btn.Font = new Font("Tahoma", 10, FontStyle.Bold);
                Email_lab.Font = new Font("Tahoma", 10, FontStyle.Bold);
                Telephone_lab.Font = new Font("Tahoma", 10, FontStyle.Bold);
                Reason_lab.Font = new Font("Tahoma", 10, FontStyle.Bold);
                label1.Font = new Font("Tahoma", 10, FontStyle.Bold);
                Font_lab.Font = new Font("Tahoma", 10, FontStyle.Bold);
            }
            if (Font_Box.Text[0].ToString() == "2")
            {
                UserId_lab.Font = new Font("Tahoma", 12, FontStyle.Bold);
                Password_lab.Font = new Font("Tahoma", 12, FontStyle.Bold);
                UserName_lab.Font = new Font("Tahoma", 12, FontStyle.Bold);
                Role_lab.Font = new Font("Tahoma", 12, FontStyle.Bold);
                OK_btn.Font = new Font("Tahoma", 12, FontStyle.Bold);
                Home_btn.Font = new Font("Tahoma", 12, FontStyle.Bold);
                Exit_btn.Font = new Font("Tahoma", 12, FontStyle.Bold);
                Email_lab.Font = new Font("Tahoma", 12, FontStyle.Bold);
                Telephone_lab.Font = new Font("Tahoma", 12, FontStyle.Bold);
                Reason_lab.Font = new Font("Tahoma", 12, FontStyle.Bold);
                label1.Font = new Font("Tahoma", 12, FontStyle.Bold);
                Font_lab.Font = new Font("Tahoma", 12, FontStyle.Bold);
            }
            if (Font_Box.Text[0].ToString() == "3")
            {
                UserId_lab.Font = new Font("Tahoma", 14, FontStyle.Bold);
                Password_lab.Font = new Font("Tahoma", 14, FontStyle.Bold);
                UserName_lab.Font = new Font("Tahoma", 14, FontStyle.Bold);
                Role_lab.Font = new Font("Tahoma", 14, FontStyle.Bold);
                OK_btn.Font = new Font("Tahoma", 14, FontStyle.Bold);
                Home_btn.Font = new Font("Tahoma", 14, FontStyle.Bold);
                Exit_btn.Font = new Font("Tahoma", 14, FontStyle.Bold);
                Email_lab.Font = new Font("Tahoma", 14, FontStyle.Bold);
                Telephone_lab.Font = new Font("Tahoma", 14, FontStyle.Bold);
                Reason_lab.Font = new Font("Tahoma", 14, FontStyle.Bold);
                label1.Font = new Font("Tahoma", 14, FontStyle.Bold);
                Font_lab.Font = new Font("Tahoma", 14, FontStyle.Bold);
            }
            if (Font_Box.Text[0].ToString() == "4")
            {
                UserId_lab.Font = new Font("Tahoma", 15, FontStyle.Bold);
                Password_lab.Font = new Font("Tahoma", 15, FontStyle.Bold);
                UserName_lab.Font = new Font("Tahoma", 15, FontStyle.Bold);
                Role_lab.Font = new Font("Tahoma", 15, FontStyle.Bold);
                OK_btn.Font = new Font("Tahoma", 15, FontStyle.Bold);
                Home_btn.Font = new Font("Tahoma", 15, FontStyle.Bold);
                Exit_btn.Font = new Font("Tahoma", 15, FontStyle.Bold);
                Email_lab.Font = new Font("Tahoma", 15, FontStyle.Bold);
                Telephone_lab.Font = new Font("Tahoma", 15, FontStyle.Bold);
                Reason_lab.Font = new Font("Tahoma", 15, FontStyle.Bold);
                label1.Font = new Font("Tahoma", 15, FontStyle.Bold);
                Font_lab.Font = new Font("Tahoma", 15, FontStyle.Bold);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        
    }

    }

