﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace VotingSystem
{
    public partial class Login : Form
    {
        
        public Login()
        {
            InitializeComponent();
        }

        string strcon, strsql;
        SqlConnection mycon;
        SqlCommand command;
        public static string s;
        // To create a database

        private bool DBConnect()
        {
            try
            {
                strcon = "Data Source=localhost;Initial Catalog=VOTING;Integrated Security=True";
                // connect to the database
                mycon = new SqlConnection(strcon);
                mycon.Open();
                MessageBox.Show("Link datebase is succesfully");
                //Successful connection to database
                return true;
            }
            catch
            {
                MessageBox.Show("Link datebase is not succesfully");
                //Failure to connect database
                return false;
            }
        }

        private void Register_btn_Click(object sender, EventArgs e)
        {
            Register register = new Register();
            this.Hide();
            register.ShowDialog(this);
            //Set up the Register button action
        }

        private void Login_Load(object sender, EventArgs e)
        {
            
        }



        


        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void Reset_btn_Click(object sender, EventArgs e)
        {
            UserName_txt.Text = "";
            Password_txt.Text = "";
            UserName_txt.Select();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Set a selection box to adjust font size
            if (Font_Box.Text[0].ToString() == "1")
            {
                Username_lab.Font = new Font("Tahoma", 10, FontStyle.Bold);
                Password_lab.Font = new Font("Tahoma", 10, FontStyle.Bold);
                Register_btn.Font = new Font("Tahoma", 10, FontStyle.Bold);
                User_button.Font = new Font("Tahoma", 10, FontStyle.Bold);
                Staff_button.Font = new Font("Tahoma", 10, FontStyle.Bold);
                Comptoller_button.Font = new Font("Tahoma", 10, FontStyle.Bold);
                Login_btn.Font = new Font("Tahoma", 10, FontStyle.Bold);
                Reset_btn.Font = new Font("Tahoma", 10, FontStyle.Bold);
                Font_lab.Font = new Font("Tahoma", 10, FontStyle.Bold);
            }
            if (Font_Box.Text[0].ToString() == "2")
            {
                Username_lab.Font = new Font("Tahoma", 12, FontStyle.Bold);
                Password_lab.Font = new Font("Tahoma", 12, FontStyle.Bold);
                Register_btn.Font = new Font("Tahoma", 12, FontStyle.Bold);
                User_button.Font = new Font("Tahoma", 12, FontStyle.Bold);
                Staff_button.Font = new Font("Tahoma", 12, FontStyle.Bold);
                Comptoller_button.Font = new Font("Tahoma", 12, FontStyle.Bold);
                Login_btn.Font = new Font("Tahoma", 12, FontStyle.Bold);
                Reset_btn.Font = new Font("Tahoma", 12, FontStyle.Bold);
                Font_lab.Font = new Font("Tahoma", 12, FontStyle.Bold);
            }
            if (Font_Box.Text[0].ToString() == "3")
            {
                Username_lab.Font = new Font("Tahoma", 14, FontStyle.Bold);
                Password_lab.Font = new Font("Tahoma", 14, FontStyle.Bold);
                Register_btn.Font = new Font("Tahoma", 14, FontStyle.Bold);
                User_button.Font = new Font("Tahoma", 14, FontStyle.Bold);
                Staff_button.Font = new Font("Tahoma", 14, FontStyle.Bold);
                Comptoller_button.Font = new Font("Tahoma", 14, FontStyle.Bold);
                Login_btn.Font = new Font("Tahoma", 14, FontStyle.Bold);
                Reset_btn.Font = new Font("Tahoma", 14, FontStyle.Bold);
                Font_lab.Font = new Font("Tahoma", 14, FontStyle.Bold);
            }
            if (Font_Box.Text[0].ToString() == "4")
            {
                Username_lab.Font = new Font("Tahoma", 16, FontStyle.Bold);
                Password_lab.Font = new Font("Tahoma", 16, FontStyle.Bold);
                Register_btn.Font = new Font("Tahoma", 16, FontStyle.Bold);
                User_button.Font = new Font("Tahoma", 16, FontStyle.Bold);
                Staff_button.Font = new Font("Tahoma", 16, FontStyle.Bold);
                Comptoller_button.Font = new Font("Tahoma", 16, FontStyle.Bold);
                Login_btn.Font = new Font("Tahoma", 16, FontStyle.Bold);
                Reset_btn.Font = new Font("Tahoma", 16, FontStyle.Bold);
                Font_lab.Font = new Font("Tahoma", 16, FontStyle.Bold);
            }
        }

        private void Login_btn_Click(object sender, EventArgs e)
        { //Set up the login button action
            if (DBConnect())
            {


                if (UserName_txt.Text[0].ToString() == "U")
                //Customer login
                {
                  
                    DBConnect();
                    strsql = string.Format("select count(*) from VotingUsers where UserId ='{0}' and Password='{1}' ", UserName_txt.Text, Password_txt.Text);
                    // link customer of datebase
                    command = new SqlCommand(strsql, mycon);
                    

                    try
                    {
                        

                        if (User_button.Checked == true)
                        {
                            Topic topic  = new Topic();
                            this.Hide();
                            topic.ShowDialog(this);
                            //jump to the Topic.cs
                        }
                        else
                            MessageBox.Show("Login faill!!!!!!");
                    }
                    catch
                    {
                        MessageBox.Show("Sql statement error!!?");
                    }
                }

                if (UserName_txt.Text[0].ToString() == "S")
                {
                    strsql = string.Format("select count(*) from VotingStaff where StaffId ='{0}' and Password='{1}'", UserName_txt.Text, Password_txt.Text);
                    //connect to the VotingUsers table of datebase
                    command = new SqlCommand(strsql, mycon);
                    s = Staff_button.Text;
                    try
                    {
                        
                        if (Staff_button.Checked == true)
                        {
                            StaffManagement staffManagement = new StaffManagement();
                            this.Hide();
                            staffManagement.ShowDialog(this);
                            //jump to the staffManagement.cs
                        }
                        else
                            MessageBox.Show("Login faill!");
                    }
                    catch
                    {
                        MessageBox.Show("Sql statement error!");
                    }
                }

                if (UserName_txt.Text[0].ToString() == "C")
                {
                    strsql = string.Format("select count(*) from VotingComptoller where ComptollerId ='{0}' and Password='{1}'", UserName_txt.Text, Password_txt.Text);
                    // connect to the VotingStaff table of datebase
                    command = new SqlCommand(strsql, mycon);
                    s = Staff_button.Text;
                    try
                    {

                        if (Comptoller_button.Checked == true)
                        {
                            DataForm dataForm = new DataForm();
                            this.Hide();
                            dataForm.ShowDialog(this);
                            //jump to DataForm.cs
                        }
                        else
                            MessageBox.Show("Login faill!");
                    }
                    catch
                    {
                        MessageBox.Show("Sql statement error!");
                    }
                }
            }

            else
            {
                MessageBox.Show("User is empty or password is empty");
            }
        }
    }
}
